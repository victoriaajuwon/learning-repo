//recursion to create countdown
function countdown(n){
    if (n < 1){
        return [];
    }else{
        const countArray = countdown(n-1);
        countArray.unshift(n);
        return countArray;
    }
  }
  //testing
  console.log(countdown(5));
//recursion to create a Range of Numbers
function rangeOfNumbers(startNum, endNum){
    if (endNum < startNum){
        return [];
    } else{
        const numbers = rangeOfNumbers(startNum, endNum-1);
        numbers.push(endNum);
        return numbers;
    }
}

console.log(rangeOfNumbers(1, 5));
console.log(rangeOfNumbers(6, 9));
console.log(rangeOfNumbers(4, 4));
