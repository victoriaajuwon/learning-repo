function forecast(arr) {
  // Only change code below this line
  let newArray = arr.slice(2,4)
  return newArray;
}

// Only change code above this line
console.log(forecast(['cold', 'rainy', 'warm', 'sunny', 'cool', 'thunderstorms']));