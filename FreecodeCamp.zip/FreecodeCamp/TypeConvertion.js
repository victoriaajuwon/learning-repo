//converting string to integer without radix
function convertToInteger(str) {
    return parseInt(str);
}

//converting string to integer with radix
/** radix, which specifies the base of the number 
 * in the string. The radix can be an integer between 2 and
 * 36. **/
function convertToInteger(str) {
    return parseInt(str, 2)
  }
  
  convertToInteger("10011");

var number = convertToInteger("56");
console.log(number);