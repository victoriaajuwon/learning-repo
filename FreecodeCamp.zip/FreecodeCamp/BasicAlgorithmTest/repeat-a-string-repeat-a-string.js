function repeatStringNumTimes(str, num) {
  if (num < 1){
    return "";
  }else{
    return str + repeatStringNumTimes(str, num-1);
  }
}

repeatStringNumTimes("abc", 3);
console.log(repeatStringNumTimes("abc", 3));