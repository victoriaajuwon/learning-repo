function findLongestWordLength(str) {
  let word = str.split(" ");
  let longestString = 0;
  for (let i = 0; i< word.length; i++){
    if (word[i].length > longestString){
      longestString = word[i].length;
    }
  }
  return longestString;
}

let result = findLongestWordLength("The quick brown fox jumped over the lazy dog");
console.log(result);