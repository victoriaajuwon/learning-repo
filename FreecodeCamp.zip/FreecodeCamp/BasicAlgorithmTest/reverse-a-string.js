function reverseString(str) {
  if (str.length <=1){
    return str;
  }else{
    return reverseString(str.substring(1))+str.charAt(0);
  }
  
}

reverseString("hello");
console.log(reverseString("hello"));