function booWho(bool) {
  return typeof bool === "boolean";
}

booWho(null);
console.log(booWho(null));