//matching multiple pattern
let twinkleStar = "Twinkle, twinkle, little star";
let starRegex = /twinkle/gi; // Change this line
let result = twinkleStar.match(starRegex); // Change this line
console.log("First Solution");
console.log(result);
console.log();

//match anything with wildcard  period
/** Sometimes you won't (or don't need to) know the exact characters in your patterns. Thinking of all words that match, say, a
 * misspelling would take a long time.Luckily, you can save time using the wildcard character: .The wildcard character . will match
 * any one character. The wildcard is also called dot and period. You can use the wildcard character just like any other character in
 * the regex. For example, if you wanted to match hug, huh, hut, and hum, you can use the regex /hu./ to match all four words. **/
 
 //Exercise Instruction and solution
/** Complete the regex unRegex so that it matches the strings run, sun, fun, pun, nun, and bun. Your regex should use the wildcard character.**/
let exampleStr = "Let's have fun with regular expressions!";
let unRegex = /.un/; // Change this line
let result1 = unRegex.test(exampleStr);
console.log("Second Solution");
console.log(result1);
console.log();

//Match single characters with multiple possiblities.
/** You learned how to match literal patterns (/literal/) and wildcard character (/./). Those are the extremes of regular expressions,
 * where one finds exact matches and the other matches everything. There are options that are a balance between the two extremes. You
 * can search for a literal pattern with some flexibility with character classes. Character classes allow you to define a group of
 * characters you wish to match by placing them inside square ([ and ]) brackets. For example, you want to match bag, big, and bug
 * but not bog. You can create the regex /b[aiu]g/ to do this. The [aiu] is the character class that will only match the characters
 * a, i, or u. **/

//example
let bigStr = "big";
let bagStr = "bag";
let bugStr = "bug";
let bogStr = "bog";
let bgRegex = /b[aiu]g/;
bigStr.match(bgRegex);
bagStr.match(bgRegex);
bugStr.match(bgRegex);
bogStr.match(bgRegex);

//Exercise instruction and solution
/** Instruction: Use a character class with vowels (a, e, i, o, u) in your regex vowelRegex to find all the vowels in the string
 * quoteSample. Note: Be sure to match both upper- and lowercase vowels. 
 * Incomplete code: 
 * let quoteSample = "Beware of bugs in the above code; I have only proved it correct, not tried it.";
 * let vowelRegex = /change/; // Change this line
 * let result = vowelRegex; // Change this line**/
//solution
let quoteSample = "Beware of bugs in the above code; I have only proved it correct, not tried it.";
let vowelRegex = /[aeiou]/gi; // Change this line
let result2 = quoteSample.match(vowelRegex); // Change this line
console.log("Third Solution");
console.log(result2)
console.log();

//Match Letters of the Alphabet
/** You saw how you can use character sets to specify a group of characters to match, but that's a lot of typing when you need to
 * match a large range of characters (for example, every letter in the alphabet). Fortunately, there is a built-in feature that makes
 * this short and simple. Inside a character set, you can define a range of characters to match using a hyphen character: -.
 * For example, to match lowercase letters a through e you would use [a-e].**/
//Example

//Exercise
/**Instruction
 * Match all the letters in the string quoteSample. Note: Be sure to match both uppercase and lowercase letters.**/
/**Incomplete code
 * let quoteSample = "The quick brown fox jumps over the lazy dog.";
 * let alphabetRegex = /change/; // Change this line
 * let result = alphabetRegex; // Change this line**/
//solution
let quoteSample1 = "The quick brown fox jumps over the lazy dog.";
let alphabetRegex = /[a-z]/gi; // Change this line
let result3 = quoteSample1.match(alphabetRegex); // Change this line
console.log("Fourth Solution");
console.log(result3)
console.log();

//Match Numbers and Letters of the Alphabet
/** Using the hyphen (-) to match a range of characters is not limited to letters. It also works to match a range of numbers.For
 * example, /[0-5]/ matches any number between 0 and 5, including the 0 and 5.Also, it is possible to combine a range of letters and
 * numbers in a single character set.**/

//Example
let jennyStr = "Jenny8675309";
let myRegex = /[a-z0-9]/ig;
jennyStr.match(myRegex);

//Exercise
/**Instruction:Create a single regex that matches a range of letters between h and s, and a range of numbers between 2 and 6. Remember
 * to include the appropriate flags in the regex. **/
/**incomplete code: 
 * let quoteSample = "Blueberry 3.141592653s are delicious.";
 * let myRegex = /change/; // Change this line
 * let result = myRegex; // Change this line **/
//solution
let quoteSample2 = "Blueberry 3.141592653s are delicious.";
let myRegex1 = /[h-s2-6]/ig; // Change this line
let result4 = quoteSample2.match(myRegex1); // Change this line
console.log("Fifth Solution");
console.log(result4)
console.log();

//Match single characters not specified
/** During a college group project, one of my team members consistently missed their deadlines, creating challenges for the group. As
 * the group leader, I took the initiative to communicate with this team member to understand the reasons for their delays. We had an
 * open and honest conversation, during which the team member confided in me that they were going through a difficult personal
 * situation. In response to this, we reached an agreement: I reduced their workload and redistributed some tasks to other team
 * members. After the discussion and implementation of the solution, there was an improvement in our team's performance, and we
 * successfully completed the project. **/
//Exercise
/**Instruction: Create a single regex that matches all characters that are not a number or a vowel. Remember to include the appropriate
 * flags in the regex. **/
/**Incomplete Code 
 * let quoteSample = "3 blind mice.";
 * let myRegex = /change/; // Change this line
 * let result = myRegex; // Change this line**/

 //Solution
 let quoteSample3 = "3 blind mice.";
 let myRegex2 = /[^aeiou0-9]/gi; // Change this line
 let result5 = quoteSample3.match(myRegex2); // Change this line
 console.log("Sixth Solution");
 console.log(result5);
 console.log();

//Match Characters that Occur One or More Times
/** Sometimes, you need to match a character (or group of characters) that appears one or more times in a row. This means it occurs at
 * least once, and may be repeated. You can use the + character to check if that is the case. Remember, the character or pattern has
 * to be present consecutively. That is, the character has to repeat one after the other. For example, /a+/g would find one match in
 * abc and return ["a"]. Because of the +, it would also find a single match in aabc and return ["aa"]. If it were instead checking
 * the string abab, it would find two matches and return ["a", "a"] because the a characters are not in a row - there is a b between
 * them. Finally, since there is no a in the string bcd, it wouldn't find a match.**/

//Exercise
/** Instruction: You want to find matches when the letter s occurs one or more times in Mississippi. Write a regex that uses the + sign **/
/**Incomplete code:
 * let difficultSpelling = "Mississippi";
 * let myRegex = /change/; // Change this line
 * let result = difficultSpelling.match(myRegex);**/
let difficultSpelling = "Mississippi";
let myRegex3 = /s+/g; // Change this line
let result6 = difficultSpelling.match(myRegex3);
console.log("Seventh Solution");
console.log(result6);
console.log();


//Match Characters that Occur Zero or More Times
/** The last challenge used the plus + sign to look for characters that occur one or more times. There's also an option that matches
 * characters that occur zero or more times. The character to do this is the asterisk or star: *. **/

//example
let soccerWord = "gooooooooal!";
let gPhrase = "gut feeling";
let oPhrase = "over the moon";
let goRegex = /go*/;
let exampleResult1 = soccerWord.match(goRegex);
let exampleResult2 = gPhrase.match(goRegex);
let exampleResult3 = oPhrase.match(goRegex);
console.log("Example RESULT");
console.log(exampleResult1);
console.log(exampleResult2);
console.log(exampleResult3);
console.log();
//In order, the three match calls would return the values ["goooooooo"], ["g"], and null.

//Exercise
/**Instruction: For this challenge, chewieQuote has been initialized as the string Aaaaaaaaaaaaaaaarrrgh! behind the scenes.
 * Create a regex chewieRegex that uses the * character to match an uppercase A character immediately followed by zero or more
 * lowercase a characters in chewieQuote. Your regex does not need flags or character classes, and it should not match any of the
 * other quotes.**/
/**Incomplete Code: 
 * // Only change code below this line
 * let chewieRegex = /change/; // Change this line
 * // Only change code above this line
 * let result = chewieQuote.match(chewieRegex); **/

//Solution
let chewieQuote = "Aaaaaaaaaaaaaaaarrrgh!";
// Only change code below this line
let chewieRegex = /Aa*/; // Change this line
// Only change code above this line
let result7 = chewieQuote.match(chewieRegex);
console.log("Eight Solution");
console.log(result7);
console.log();

//Find Characters with Lazy Matching
/** In regular expressions, a greedy match finds the longest possible part of a string that fits the regex pattern and returns it as a
 * match. The alternative is called a lazy match, which finds the smallest possible part of the string that satisfies the regex
 * pattern. You can apply the regex /t[a-z]*i/ to the string "titanic". This regex is basically a pattern that starts with t, ends
 * with i, and has some letters in between. Regular expressions are by default greedy, so the match would return ["titani"]. It finds
 * the largest sub-string possible to fit the pattern. However, you can use the ? character to change it to lazy matching. "titanic"
 * matched against the adjusted regex of /t[a-z]*?i/ returns ["ti"]. 
 * Note: Parsing HTML with regular expressions should be avoided, but pattern matching an HTML string with regular expressions is 
 * completely fine.**/

//EXERCISE
/**Instruction: Fix the regex /<.*>/ to return the HTML tag <h1> and not the text "<h1>Winter is coming</h1>". Remember the wildcard . in a regular
 * expression matches any character.**/
/** Incomplete code:
 * let text = "<h1>Winter is coming</h1>";
 * let myRegex = /<.*>/; // Change this line
 * let result = text.match(myRegex);**/
let text = "<h1>Winter is coming</h1>";
let myRegex4 = /.*?/; // Change this line
let result8 = text.match(myRegex);
console.log("Ninth Solution");
console.log(result8);
console.log();

//Match Beginning String Patterns
/** Prior challenges showed that regular expressions can be used to look for a number of matches. They are also used to search for
 * patterns in specific positions in strings. In an earlier challenge, you used the caret character (^) inside a character set to
 * create a negated character set in the form [^thingsThatWillNotBeMatched]. Outside of a character set, the caret is used to search
 * for patterns at the beginning of strings.**/
//Example
let firstString = "Ricky is first and can be found.";
let firstRegex = /^Ricky/;
let exampleResult4= firstRegex.test(firstString);
let notFirst = "You can't find Ricky now.";
let exampleResult5 = firstRegex.test(notFirst);
console.log("Example RESULT");
console.log(exampleResult4);
console.log(exampleResult5);
console.log();
//The first test call would return true, while the second would return false.

//EXERCISE
/**Instruction:Use the caret character in a regex to find Cal only in the beginning of the string rickyAndCal.**/
/**Incomplete code:
 * let rickyAndCal = "Cal and Ricky both like racing.";
 * let calRegex = /change/; // Change this line
 * let result = calRegex.test(rickyAndCal);**/
//Solution
let rickyAndCal = "Cal and Ricky both like racing.";
let calRegex = /^Cal/; // Change this line
let result9 = calRegex.test(rickyAndCal);
console.log("Tenth Solution");
console.log(result9);
console.log();

//Match Ending String Patterns
/**In the last challenge, you learned to use the caret character to search for patterns at the beginning of strings. There is also a
 * way to search for patterns at the end of strings.You can search the end of strings using the dollar sign character $ at the end of
 * the regex.**/

//Example
let theEnding = "This is a never ending story";
let storyRegex = /story$/;
storyRegex.test(theEnding);
let noEnding = "Sometimes a story will have to end";
storyRegex.test(noEnding);

//The first "test" call would return true, while the second would return false.

//Exercise
/**Instruction: Use the anchor character "($)" to match the string caboose at the end of the string cabose**/
/**Incomplete code:
 * let caboose = "The last car on a train is the caboose";
 * let lastRegex = /change/; // Change this line
 * let result = lastRegex.test(caboose);**/

let caboose = "The last car on a train is the caboose";
let lastRegex = /caboose$/; // Change this line
let result10 = lastRegex.test(caboose);
console.log("Eleventh Result");
console.log(result10);
console.log();

//Match All Letters and Numbers
/**Using character classes, you were able to search for all letters of the alphabet with [a-z]. This kind of character class is common
 * enough that there is a shortcut for it, although it includes a few extra characters as well. The closest character class in
 * JavaScript to match the alphabet is \w. This shortcut is equal to [A-Za-z0-9_]. This character class matches upper and lowercase
 * letters plus numbers. Note, this character class also includes the underscore character (_).**/

//Example
let longHand = /[A-Za-z0-9_]+/;
let shortHand = /\w+/;
let numbers = "42";
let varNames = "important_var";
longHand.test(numbers);
shortHand.test(numbers);
longHand.test(varNames);
shortHand.test(varNames);

//Exercise: Use the shorthand character class \w to count the number of alphanumeric characters in various quotes and strings.
let quoteSample4 = "The five boxing wizards jump quickly.";
let alphabetRegexV2 = /\w/g;//(corrected) // Change this line: let alphabetRegexV2 = /change/;
let result11 = quoteSample4.match(alphabetRegexV2).length;

//Match Everything But Letters and Numbers
/**You've learned that you can use a shortcut to match alphanumerics [A-Za-z0-9_] using \w. A natural pattern you might want to search for is the opposite of alphanumerics.

You can search for the opposite of the \w with \W. Note, the opposite pattern uses a capital letter. This shortcut is the same as [^A-Za-z0-9_].**/
//Example
let shortHand1 = /\W/;
let numbers1 = "42%";
let sentence = "Coding!";
numbers1.match(shortHand1);
sentence.match(shortHand1);

//Exercise: Use the shorthand character class \W to count the number of non-alphanumeric characters in various quotes and strings.
let quoteSample5 = "The five boxing wizards jump quickly.";
let nonAlphabetRegex = /\W/g; // Change this line: let nonAlphabetRegex = /change/
let result12 = quoteSample5.match(nonAlphabetRegex).length;


//Match All Numbers
/**The shortcut to look for digit characters is \d, with a lowercase d. This is equal to the character class [0-9], which looks for a single character of any number between zero and nine.**/
let movieName1 = "2001: A Space Odyssey";
let numRegex = /\d/g; // Change this line
let result13 = movieName1.match(numRegex).length;

//Match All Non-Numbers
/**The shortcut to look for non-digit characters is \D. This is equal to the character class [^0-9], which looks for a single character that is not a number between zero and nine.**/
let movieName2 = "2001: A Space Odyssey";
let noNumRegex = /\D/g; // Change this line
let result14 = movieName2.match(noNumRegex).length;

//Restrict Possible Usernames
/**Usernames are used everywhere on the internet. They are what give users a unique identity on their favorite sites. You need to 
 * check all the usernames in a database. Here are some simple rules that users have to follow when creating their username.
 * Usernames can only use alphanumeric characters. The only numbers in the username have to be at the end. There can be zero or more
 * of them at the end. Username cannot start with the number. Username letters can be lowercase and uppercase. Usernames have to be at
 * least two characters long. A two-character username can only use alphabet letters as characters.**/
//Exercise Instruction: Change the regex userCheck to fit the constraints listed above.
let username = "JackOfAllTrades";
let userCheck = /^[a-z][a-z]+\d*$|^[a-z]\d\d+$/i; // Change this line
let result15 = userCheck.test(username);


