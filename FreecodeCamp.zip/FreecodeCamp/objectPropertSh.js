const createPerson = (name, age, gender) => {
    // Only change code below this line
    return {
      name,
      age,
      gender
    };
    // Only change code above this line
  };
  console.log(createPerson("Zodiac Hasbro", 56, "male"));
  const createPerson1 = (name, age, gender) => ({name, age, gender});
  console.log(createPerson1("Zodiac Hasbro", 56, "male"));


  //
  // Only change code below this line
const bicycle = {
    gear: 2,
    setGear: function(newGear) {
      this.gear = newGear;
    }
  };
  // Only change code above this line
  bicycle.setGear(3);
  console.log(bicycle.gear);

  // Only change code below this line
const bicycle1 = {
    gear: 2,
    setGear(newGear) {
      this.gear = newGear;
    }
  };
  // Only change code above this line
  bicycle1.setGear(3);
  console.log(bicycle1.gear);