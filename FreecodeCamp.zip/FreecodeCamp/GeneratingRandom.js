//method to generate random fraction
function randomFraction() {
    /*JavaScript has a Math.random() function that generates
    a random decimal number between 0 (inclusive) and 1
    (exclusive). Thus Math.random() can return a 0 but never
    return a 1 */
    return Math.random();
  }

  //method to generate random whole number
  function randomWholeNum() {
    return Math.floor(Math.random() * 10);
  }

  //method to generate random number with a range
  function randomNumInRange(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
  }
  var generatedFraction = randomFraction();
  console.log(generatedFraction);

  var generatedWholeNumber = randomWholeNum();
  console.log(generatedWholeNumber);

  var generatedWholeNum = randomNumInRange(2, 6);
  console.log(generatedWholeNumber);