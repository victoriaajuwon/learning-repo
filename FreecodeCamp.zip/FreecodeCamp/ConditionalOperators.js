//use conditional (ternary) operators
/** The conditional operator, also called the ternary operator, can be used as a
 * one line if-else expression.The syntax is a ? b : c, where a is the condition,
 * b is the code to run when the condition returns true, and c is the code to run
 * when the condition returns false. **/
//example
//code written with if/else statement
function findGreater(a, b) {
    if(a > b) {
      return "a is greater";
    }
    else {
      return "b is greater or equal";
    }
  }
//code rewritten using confitional operators
function findGreater(a, b) {
    return a > b ? "a is greater" : "b is greater or equal";
  }

  //practice
  function checkEqual(a, b) {
    return a === b? "Equal" : "Not Equal";
  }
  
  //testing
  var testData = checkEqual(1, 2);
  console.log(testData);

//use multiple conditional (ternary) operators
/** In the previous challenge, you used a single conditional operator. You can
 * also chain them together to check for multiple conditions. It is considered
 * best practice to format multiple conditional operators such that each
 * condition is on a separate line, as shown above. Using multiple conditional
 * operators without proper indentation may make your code hard to read**/
//code written with if/else statement
function findGreaterOrEqual(a, b) {
    if (a === b) {
      return "a and b are equal";
    }
    else if (a > b) {
      return "a is greater";
    }
    else {
      return "b is greater";
    }
  }
//code rewritten using confitional operators
function findGreaterOrEqual(a, b) {
    return (a === b) ? "a and b are equal" 
      : (a > b) ? "a is greater" 
      : "b is greater";
  }

  //practice
  function checkSign(num) {
    return (num < 0) ? "negative"
    : (num > 0)? "positive"
    :"zero";
  }
  
  //testing
  var testData1 = checkSign(10);
  console.log(testData1);