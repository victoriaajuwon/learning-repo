public enum Direction {
    UP,
    DOWN,
    IDLE
}