public class DoubleOrNothing {

    public void playGame() {

    }
}