import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Joke {
    String setup;
    String punchline;
}
