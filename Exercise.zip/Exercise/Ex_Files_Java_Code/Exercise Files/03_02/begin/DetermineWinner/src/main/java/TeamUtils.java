import java.util.List;
import java.util.Random;

public class TeamUtils {
    
    public static void generateTeamsScores(List<Team> teams,
                                           int numberOfRounds) {
        Random random = new Random();
        teams.forEach(team -> {
            for (int i = 0; i < numberOfRounds; i++) {
                team.getScores().add(random.nextInt(11));
            }
        });
    }

    public static void revealResults(List<Team> teams) {

    }

}