package com.tau.base;

public class BaseUtil {
    //In this class, we can add anything we want to share between steps
    public String userFullName;
}
