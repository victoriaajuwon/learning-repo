﻿
namespace Framework.Model
{
    public class TeamStanding
    {
        public int Rank { get; set; }
        public string Name { get; set; }
        public string Record { get; set; }

    }
}
